==================
``String`` methods
==================

Extendables provides a number of additional string munging and manipulation methods for `String` objects. Most of these will look familiar if you've coded in other languages before.

.. contents::

.. include:: ../../patches/doc/jsdoc/String.rst
   :start-after: class-methods