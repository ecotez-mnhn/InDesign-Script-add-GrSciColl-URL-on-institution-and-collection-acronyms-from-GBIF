==================
``Object`` methods
==================

.. contents::

.. include:: ../../patches/doc/jsdoc/Object.rst
   :start-after: class-methods